This archive contains the original site as it was before it got changed to Materialize.
In order to flip the site to a Bootstrap version, overwrite all templates with the ones in this archive.

Also overwrite the css and js files included.
After that, the materialise files can be removed to save space.

Once done, replace the 'requirements.txt' file with the one in this archive, to ensure correct form handling.

Next, in 'settings.py', remove 'materializecssform' from the INSTALLED_APPS section and add 'crispy_forms' in its place.
Then underneath the INSTALLED_APPS section, add CRISPY_TEMPLATE_PACK = 'bootstrap4' to make sure the correct form type is used
by crispy_forms.

** Bear in mind, these templates in this state are not as far developed as the current Materialize version and will need work **
